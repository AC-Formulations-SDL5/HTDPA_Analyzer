#!/bin/bash

cd "$(dirname "$0")" || exit 1

APP_TITLE="HTDPA Analyzer"
VENV_DIR=".htdpa_venv"
REQ_FILE="requirements_htdpa_dashboard.txt"
APP_FILE="htdpa_release_dashboard.py"
STAMP_FILE="$VENV_DIR/.requirements_installed"
LOG_FILE="HTDPA_Analyzer_launch.log"
URL="http://127.0.0.1:8501"

# Keep a complete diagnostic log beside the application.
exec > >(tee -a "$LOG_FILE") 2>&1

pause_and_exit() {
  code="$1"
  echo
  echo "=============================================="
  echo "HTDPA Analyzer could not start."
  echo "A diagnostic log was saved here:"
  echo "$(pwd)/$LOG_FILE"
  echo "=============================================="
  echo
  read -r -p "Press Return to close this window..." _
  exit "$code"
}

echo
echo "=============================================="
echo "              HTDPA Analyzer"
echo "=============================================="
echo "Launch time: $(date)"
echo

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: Python 3 was not found on this Mac."
  echo "Install Python 3, then launch HTDPA Analyzer again."
  pause_and_exit 1
fi

PYTHON3="$(command -v python3)"
echo "Using Python: $PYTHON3"
"$PYTHON3" --version || pause_and_exit 1

if [ ! -f "$APP_FILE" ]; then
  echo "ERROR: $APP_FILE is missing. Keep all HTDPA files in the same folder."
  pause_and_exit 1
fi

if [ ! -d "$VENV_DIR" ]; then
  echo
  echo "First launch: creating the private HTDPA environment..."
  "$PYTHON3" -m venv "$VENV_DIR" || pause_and_exit 1
fi

PYTHON="$VENV_DIR/bin/python"

if [ ! -x "$PYTHON" ]; then
  echo "ERROR: The private Python environment is incomplete."
  echo "Delete the hidden .htdpa_venv folder and try again."
  pause_and_exit 1
fi

if [ ! -f "$STAMP_FILE" ] || [ "$REQ_FILE" -nt "$STAMP_FILE" ]; then
  echo
  echo "Installing/updating HTDPA components. This is only normally needed on first launch..."
  "$PYTHON" -m pip install --upgrade pip || pause_and_exit 1
  "$PYTHON" -m pip install -r "$REQ_FILE" || pause_and_exit 1
  touch "$STAMP_FILE" || pause_and_exit 1
fi

echo
echo "Starting $APP_TITLE..."
echo "The dashboard will open at $URL"
echo "Keep this Terminal window open while using the Analyzer."
echo

"$PYTHON" -m streamlit run "$APP_FILE" \
  --server.headless true \
  --server.address 127.0.0.1 \
  --server.port 8501 \
  --browser.gatherUsageStats false &
SERVER_PID=$!

# Wait up to about 30 seconds for the local server to respond.
i=0
while [ "$i" -lt 60 ]; do
  if ! kill -0 "$SERVER_PID" 2>/dev/null; then
    echo "ERROR: Streamlit stopped before the dashboard became available."
    wait "$SERVER_PID"
    pause_and_exit 1
  fi
  if command -v curl >/dev/null 2>&1 && curl -fsS "$URL/_stcore/health" >/dev/null 2>&1; then
    break
  fi
  sleep 0.5
  i=$((i + 1))
done

if command -v open >/dev/null 2>&1; then
  open "$URL"
else
  echo "Open this address in your browser: $URL"
fi

echo "HTDPA Analyzer is running."
echo "When finished, press Control-C or close this Terminal window."

trap 'echo; echo "Stopping HTDPA Analyzer..."; kill "$SERVER_PID" 2>/dev/null; exit 0' INT TERM EXIT
wait "$SERVER_PID"
status=$?
trap - INT TERM EXIT

if [ "$status" -ne 0 ]; then
  pause_and_exit "$status"
fi
