@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title HTDPA Analyzer

set "VENV_DIR=.htdpa_venv"
set "REQ_FILE=requirements_htdpa_dashboard.txt"
set "APP_FILE=htdpa_release_dashboard.py"
set "LOG_FILE=HTDPA_Analyzer_Windows.log"

>"%LOG_FILE%" echo HTDPA Analyzer Windows launcher log
>>"%LOG_FILE%" echo Started: %date% %time%
>>"%LOG_FILE%" echo Folder: %cd%

echo.
echo ==============================================
echo               HTDPA Analyzer
echo ==============================================
echo.
echo This window must stay open while HTDPA Analyzer is running.
echo.

if not exist "%APP_FILE%" (
    echo ERROR: %APP_FILE% was not found.
    >>"%LOG_FILE%" echo ERROR: %APP_FILE% was not found.
    goto :FAIL
)
if not exist "%REQ_FILE%" (
    echo ERROR: %REQ_FILE% was not found.
    >>"%LOG_FILE%" echo ERROR: %REQ_FILE% was not found.
    goto :FAIL
)

where py >nul 2>nul
if not errorlevel 1 (
    set "PYEXE=py"
    set "PYARG=-3"
    >>"%LOG_FILE%" echo Using Python launcher: py -3
    goto :PYFOUND
)

where python >nul 2>nul
if not errorlevel 1 (
    set "PYEXE=python"
    set "PYARG="
    >>"%LOG_FILE%" echo Using Python: python
    goto :PYFOUND
)

echo ERROR: Python 3 was not found on this computer.
echo Install Python 3 from python.org and enable "Add python.exe to PATH".
>>"%LOG_FILE%" echo ERROR: Python 3 not found.
goto :FAIL

:PYFOUND
if not exist "%VENV_DIR%\Scripts\python.exe" (
    echo First launch: creating the private HTDPA environment...
    >>"%LOG_FILE%" echo Creating virtual environment...
    "%PYEXE%" %PYARG% -m venv "%VENV_DIR%" >>"%LOG_FILE%" 2>&1
    if errorlevel 1 (
        echo ERROR: Could not create the Python environment.
        goto :FAIL
    )
)

set "PYTHON=%VENV_DIR%\Scripts\python.exe"

if not exist "%VENV_DIR%\.requirements_installed" (
    echo First launch: installing HTDPA components...
    echo This can take several minutes on the first run.
    >>"%LOG_FILE%" echo Installing requirements...
    "%PYTHON%" -m pip install --upgrade pip >>"%LOG_FILE%" 2>&1
    if errorlevel 1 (
        echo ERROR: pip upgrade failed.
        goto :FAIL
    )
    "%PYTHON%" -m pip install -r "%REQ_FILE%" >>"%LOG_FILE%" 2>&1
    if errorlevel 1 (
        echo ERROR: Package installation failed.
        goto :FAIL
    )
    type nul > "%VENV_DIR%\.requirements_installed"
)

echo.
echo Starting HTDPA Analyzer...
echo Browser address: http://127.0.0.1:8501
echo.
>>"%LOG_FILE%" echo Starting Streamlit...

start "" cmd /c "timeout /t 3 /nobreak >nul & start \"\" http://127.0.0.1:8501"
"%PYTHON%" -m streamlit run "%APP_FILE%" --server.address 127.0.0.1 --server.port 8501 --server.headless true --browser.gatherUsageStats false >>"%LOG_FILE%" 2>&1

set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
    echo.
    echo HTDPA Analyzer stopped with an error.
    >>"%LOG_FILE%" echo Streamlit exited with code %RC%.
    goto :FAIL
)

echo.
echo HTDPA Analyzer has stopped.
pause
exit /b 0

:FAIL
echo.
echo ----------------------------------------------
echo HTDPA Analyzer could not start.
echo The error log is:
echo   %cd%\%LOG_FILE%
echo.
echo Send HTDPA_Analyzer_Windows.log back for diagnosis.
echo ----------------------------------------------
pause
exit /b 1
